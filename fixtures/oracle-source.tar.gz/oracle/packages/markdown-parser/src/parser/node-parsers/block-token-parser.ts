import type { AdmonitionNode, MarkdownToken, ParagraphNode, ParsedNode, ParseOptions, VmrContainerNode } from '../../types'
import type { ParseInlineTokensFn } from '../inline-parsers/inline-parser-types'
import { escapeTagForRegExp, findTagCloseIndexOutsideQuotes } from '../../htmlTagUtils'
import { normalizeCustomTag } from '../customHtmlTags'
import { buildAllowedHtmlTagSet } from '../html-tag-sets'
import { parseFenceToken } from '../inline-parsers/fence-parser'
import { createLinkifyDemotionContextTracker } from '../linkifyHeuristics'
import { applyNodeSourceMap, applyNodeSourceMapRange, createSourceMapFromOffsets } from '../node-source-map'
import { isParseContext } from '../parse-context'
import { parseBlockquote } from './blockquote-parser'
import { parseCodeBlock } from './code-block-parser'
import { parseDefinitionList } from './definition-list-parser'
import { parseFootnote } from './footnote-parser'
import { parseHeading } from './heading-parser'
import { parseHtmlBlock } from './html-block-parser'
import { parseList } from './list-parser'
import { parseMathBlock } from './math-block-parser'
import { parseTable } from './table-parser'
import { parseThematicBreak } from './thematic-break-parser'

interface HtmlTagSetCacheEntry {
  allowedTagSet: Set<string>
  customTagSet: Set<string> | null
}

let emptyHtmlTagSets: HtmlTagSetCacheEntry | null = null
const HTML_TAG_SET_CACHE = new WeakMap<readonly string[], HtmlTagSetCacheEntry>()

function getEmptyHtmlTagSets() {
  if (!emptyHtmlTagSets) {
    emptyHtmlTagSets = {
      allowedTagSet: buildAllowedHtmlTagSet(),
      customTagSet: null,
    }
  }
  return emptyHtmlTagSets
}

function getHtmlTagSets(customTags?: readonly string[]) {
  if (!customTags || customTags.length === 0)
    return getEmptyHtmlTagSets()
  const cached = HTML_TAG_SET_CACHE.get(customTags)
  if (cached)
    return cached
  const normalized = customTags.map(normalizeCustomTag).filter(Boolean)
  if (!normalized.length) {
    const entry = getEmptyHtmlTagSets()
    HTML_TAG_SET_CACHE.set(customTags, entry)
    return entry
  }
  const entry = {
    allowedTagSet: buildAllowedHtmlTagSet({ customHtmlTags: customTags }),
    customTagSet: new Set(normalized),
  }
  HTML_TAG_SET_CACHE.set(customTags, entry)
  return entry
}

function parseVmrContainer(
  tokens: MarkdownToken[],
  index: number,
  options: ParseOptions | undefined,
  parseInlineTokens: ParseInlineTokensFn,
): [VmrContainerNode, number] {
  const openToken = tokens[index]

  // Extract name from class attribute (e.g., "vmr-container vmr-container-viewcode:topo-test-001")
  // Handle multiple class values by looking for vmr-container-* anywhere in the string
  const attrs = openToken.attrs as [string, string][] | null
  let name = ''
  const containerAttrs: Record<string, string> = {}

  if (attrs) {
    for (const [key, value] of attrs) {
      if (key === 'class') {
        // Match vmr-container-* anywhere in the class string, not just at the end
        const match = value.match(/(?:\s|^)vmr-container-(\S+)/)
        if (match) {
          name = match[1]
        }
      }
      else if (key.startsWith('data-')) {
        // Extract data attributes (e.g., "data-devId" -> "devId")
        const attrName = key.slice(5)
        // Try to parse JSON values; fallback to raw string if parsing fails
        try {
          containerAttrs[attrName] = JSON.parse(value)
        }
        catch {
          containerAttrs[attrName] = value
        }
      }
    }
  }

  const children: ParsedNode[] = []
  const linkifyContext = createLinkifyDemotionContextTracker(options, true)
  let j = index + 1

  // Parse children until we find the closing token
  while (j < tokens.length && tokens[j].type !== 'vmr_container_close') {
    if (tokens[j].type === 'paragraph_open') {
      // Handle paragraph tokens (plain text)
      const contentToken = tokens[j + 1]
      if (contentToken) {
        const childrenArr = (contentToken.children as MarkdownToken[]) || []
        const paragraphNode = {
          type: 'paragraph',
          children: parseInlineTokens(childrenArr || [], undefined, undefined, linkifyContext.options()),
          raw: String(contentToken.content ?? ''),
        } as ParsedNode
        if (options?.includeSourceMap)
          applyNodeSourceMap(paragraphNode, tokens[j], options)
        children.push(paragraphNode)
        linkifyContext.remember(paragraphNode.raw)
      }
      j += 3 // Skip paragraph_open, inline, paragraph_close
    }
    else if (
      tokens[j].type === 'bullet_list_open'
      || tokens[j].type === 'ordered_list_open'
    ) {
      // Handle list tokens
      const [listNode, newIndex] = parseList(tokens, j, linkifyContext.options(), parseInlineTokens)
      if (options?.includeSourceMap)
        applyNodeSourceMap(listNode, tokens[j], options)
      children.push(listNode)
      linkifyContext.remember(listNode.raw)
      j = newIndex
    }
    else if (tokens[j].type === 'blockquote_open') {
      // Handle blockquote tokens
      const [blockquoteNode, newIndex] = parseBlockquote(tokens, j, linkifyContext.options(), parseInlineTokens)
      if (options?.includeSourceMap)
        applyNodeSourceMap(blockquoteNode, tokens[j], options)
      children.push(blockquoteNode)
      linkifyContext.remember(blockquoteNode.raw)
      j = newIndex
    }
    else {
      // Handle other basic block tokens (heading, code_block, fence, etc.)
      const handled = parseBasicBlockToken(tokens, j, linkifyContext.options(), parseInlineTokens)
      if (handled) {
        children.push(handled[0])
        linkifyContext.remember(handled[0].raw)
        j = handled[1]
      }
      else {
        j++
      }
    }
  }

  const hasCloseToken = j < tokens.length && tokens[j].type === 'vmr_container_close'
  const closed = (hasCloseToken && openToken.meta?.unclosed !== true) || !!options?.final

  // Build raw content
  let raw = `::: ${name}`
  if (Object.keys(containerAttrs).length > 0) {
    raw += ` ${JSON.stringify(containerAttrs)}`
  }
  raw += '\n'
  if (children.length > 0) {
    // Prefer original Markdown (openToken.raw); rebuilding from tokens may lose formatting.
    raw += openToken.raw ?? children.map(c => c.raw).join('\n')
    raw += '\n'
  }
  raw += ':::'

  const containerNode: VmrContainerNode = {
    type: 'vmr_container',
    name,
    loading: !closed,
    attrs: Object.keys(containerAttrs).length > 0 ? containerAttrs : undefined,
    children,
    raw,
  }

  // Skip the closing token when present; otherwise we're already at the end.
  return [containerNode, hasCloseToken ? (j + 1) : j]
}

function applyPairedBlockSourceMap<TNode extends ParsedNode>(
  node: TNode,
  openToken: MarkdownToken,
  closeToken: MarkdownToken | undefined,
  options?: ParseOptions,
) {
  if (closeToken?.type.endsWith('_close')) {
    let endLine = Array.isArray(closeToken.map) ? Number(closeToken.map[1]) : Number.NaN
    if (!Number.isFinite(endLine))
      endLine = Array.isArray(openToken.map) ? Number(openToken.map[1]) + 1 : Number.NaN
    return applyNodeSourceMapRange(node, openToken, endLine, options)
  }

  return applyNodeSourceMap(node, openToken, options)
}

function stripWrapperNewlines(s: string) {
  // Preserve inner whitespace/indentation, but drop a single leading/trailing newline
  // introduced by the common pattern: <tag>\n...\n</tag>
  return s.replace(/^\r?\n/, '').replace(/\r?\n$/, '')
}

// Custom-tag regexes are compiled once per tag name and reused across parses.
// The `.openAny`/`.closeAny` variants are non-anchored so callers can reuse a
// single compiled RegExp with `lastIndex` per candidate `<` position instead
// of allocating a fresh RegExp and slicing the remaining source per site.
const tagRegexEntryCache = new Map<string, TagRegexEntry>()

interface TagRegexEntry {
  strip: RegExp
  search: RegExp
  openAny: RegExp
  closeAny: RegExp
}

function getTagRegexEntry(tag: string): TagRegexEntry {
  let entry = tagRegexEntryCache.get(tag)
  if (entry)
    return entry

  const escaped = escapeTagForRegExp(tag)
  entry = {
    strip: new RegExp(`[\\t ]*<\\s*\\/\\s*${escaped}[^>]*$`, 'i'),
    search: new RegExp(`<\\s*${escaped}(?=\\s|>|/)`, 'gi'),
    openAny: new RegExp(`<\\s*${escaped}(?=\\s|>|/)`, 'gi'),
    closeAny: new RegExp(`<\\s*\\/\\s*${escaped}(?=\\s|>)`, 'gi'),
  }
  tagRegexEntryCache.set(tag, entry)
  return entry
}

function stripTrailingPartialClosingTag(inner: string, tag: string) {
  if (!inner || !tag)
    return inner
  const re = getTagRegexEntry(tag).strip
  return inner.replace(re, '')
}

function findMatchingCloseTagRange(
  rawHtml: string,
  tag: string,
  startIndex: number,
) {
  if (!rawHtml || !tag)
    return null

  const lowerTag = tag.toLowerCase()
  const { openAny, closeAny } = getTagRegexEntry(lowerTag)

  let depth = 0
  let index = Math.max(0, startIndex)

  while (index < rawHtml.length) {
    const lt = rawHtml.indexOf('<', index)
    if (lt === -1)
      break

    closeAny.lastIndex = lt
    const closeMatch = closeAny.exec(rawHtml)
    if (closeMatch?.index === lt) {
      const endRel = findTagCloseIndexOutsideQuotes(rawHtml.slice(lt))
      if (endRel === -1)
        return null
      if (depth === 0) {
        return {
          start: lt,
          end: lt + endRel + 1,
        }
      }
      depth--
      index = lt + endRel + 1
      continue
    }

    openAny.lastIndex = lt
    const openMatch = openAny.exec(rawHtml)
    if (openMatch?.index === lt) {
      const endRel = findTagCloseIndexOutsideQuotes(rawHtml.slice(lt))
      if (endRel === -1)
        return null
      const raw = rawHtml.slice(lt, lt + endRel + 1)
      if (!/\/\s*>$/.test(raw))
        depth++
      index = lt + endRel + 1
      continue
    }

    index = lt + 1
  }

  return null
}

function findNextCustomHtmlBlockFromSource(
  source: string,
  tag: string,
  startIndex: number,
): { raw: string, start: number, end: number } | null {
  if (!source || !tag)
    return null

  const lowerTag = tag.toLowerCase()
  const { search, openAny, closeAny } = getTagRegexEntry(lowerTag)
  search.lastIndex = Math.max(0, startIndex || 0)
  const openMatch = search.exec(source)
  if (!openMatch || openMatch.index == null)
    return null

  const openStart = openMatch.index
  const openSlice = source.slice(openStart)
  const openEndRel = findTagCloseIndexOutsideQuotes(openSlice)
  if (openEndRel === -1)
    return null
  const openEnd = openStart + openEndRel

  // Self-closing custom tags: treat as a complete block
  if (/\/\s*>\s*$/.test(openSlice.slice(0, openEndRel + 1))) {
    const end = openEnd + 1
    return { raw: source.slice(openStart, end), start: openStart, end }
  }

  let depth = 1
  let i = openEnd + 1

  const isOpenAt = (pos: number) => {
    openAny.lastIndex = pos
    return openAny.exec(source)?.index === pos
  }
  const isCloseAt = (pos: number) => {
    closeAny.lastIndex = pos
    return closeAny.exec(source)?.index === pos
  }

  while (i < source.length) {
    const lt = source.indexOf('<', i)
    if (lt === -1) {
      // No more tags in the remaining source; treat as unclosed streaming block.
      return { raw: source.slice(openStart), start: openStart, end: source.length }
    }

    if (isCloseAt(lt)) {
      const gt = source.indexOf('>', lt)
      if (gt === -1)
        return null
      depth--
      if (depth === 0) {
        const end = gt + 1
        return { raw: source.slice(openStart, end), start: openStart, end }
      }
      i = gt + 1
      continue
    }

    if (isOpenAt(lt)) {
      const rel = findTagCloseIndexOutsideQuotes(source.slice(lt))
      if (rel === -1)
        return null
      depth++
      i = lt + rel + 1
      continue
    }

    i = lt + 1
  }

  // If the closing tag hasn't arrived yet (streaming), return a partial block
  // from the opening tag to end-of-source. This preserves original lines like
  // `---` so inner markdown can render progressively.
  return { raw: source.slice(openStart), start: openStart, end: source.length }
}

function clampNonNegative(n: number) {
  return Number.isFinite(n) && n > 0 ? n : 0
}

function lineToIndex(source: string, line: number) {
  // markdown-it token.map uses 0-based line numbers.
  const targetLine = clampNonNegative(line)
  if (!source || targetLine <= 0)
    return 0

  let currentLine = 0
  for (let i = 0; i < source.length; i++) {
    if (source[i] === '\n') {
      currentLine++
      if (currentLine === targetLine)
        return i + 1
    }
  }
  return source.length
}

export function parseBasicBlockToken(
  tokens: MarkdownToken[],
  index: number,
  options: ParseOptions | undefined,
  parseInlineTokens: ParseInlineTokensFn,
): [ParsedNode, number] | null {
  const token = tokens[index]
  const includeSourceMap = options?.includeSourceMap === true
  switch (token.type) {
    case 'heading_open': {
      const node = parseHeading(tokens, index, options, parseInlineTokens)
      if (includeSourceMap)
        applyNodeSourceMap(node, token, options)
      return [node, index + 3]
    }

    case 'code_block': {
      const node = parseCodeBlock(token)
      if (includeSourceMap)
        applyNodeSourceMap(node, token, options)
      return [node, index + 1]
    }

    case 'fence': {
      const node = parseFenceToken(token)
      if (includeSourceMap)
        applyNodeSourceMap(node, token, options)
      return [node, index + 1]
    }

    case 'math_block': {
      const node = parseMathBlock(token)
      if (includeSourceMap)
        applyNodeSourceMap(node, token, options)
      return [node, index + 1]
    }

    case 'html_block': {
      const htmlBlockNode = parseHtmlBlock(token)
      const tagSets = htmlBlockNode.tag ? getHtmlTagSets(options?.customHtmlTags) : null
      if (htmlBlockNode.tag && htmlBlockNode.loading && tagSets && !tagSets.allowedTagSet.has(htmlBlockNode.tag)) {
        const raw = String(token.content ?? '')
        const content = raw.replace(/\n+$/, '')
        const paragraphNode: ParagraphNode = {
          type: 'paragraph',
          children: content ? [{ type: 'text', content, raw: content }] : [],
          raw: content,
        }
        if (includeSourceMap)
          applyNodeSourceMap(paragraphNode, token, options)
        return [
          paragraphNode,
          index + 1,
        ]
      }
      if (htmlBlockNode.tag && tagSets?.customTagSet?.has(htmlBlockNode.tag)) {
        const tag = htmlBlockNode.tag
        // markdown-it can normalize html_block token.content and lose original lines.
        // Re-extract the next full <tag>...</tag> block from the original source.
        const context = isParseContext(options) ? options : undefined
        const source = String(context?.sourceMarkdown ?? '')
        const cursor = Number(context?.customHtmlBlockCursor ?? 0)

        // If markdown-it provides a source map for this token, prefer anchoring the
        // re-extraction to that line range. This avoids accidentally matching an
        // earlier occurrence of the same custom tag that was tokenized as inline.
        // Use the incrementally cached line-start offsets when available (O(1))
        // instead of re-scanning the source from index 0 per html_block token.
        const mappedLine = Number(token.map?.[0] ?? 0)
        const mappedLineStart = Array.isArray(token.map)
          ? context?.sourceLineOffsets?.[mappedLine] ?? lineToIndex(source, mappedLine)
          : 0
        const searchStart = Math.max(clampNonNegative(cursor), clampNonNegative(mappedLineStart))

        const fromSource = findNextCustomHtmlBlockFromSource(source, tag, searchStart)
        if (fromSource && context)
          context.customHtmlBlockCursor = fromSource.end

        const rawHtml = String(fromSource?.raw ?? htmlBlockNode.raw ?? '')

        const openEnd = findTagCloseIndexOutsideQuotes(rawHtml)
        const openTag = openEnd !== -1 ? rawHtml.slice(0, openEnd + 1) : rawHtml
        const selfClosing = openEnd !== -1 && /\/\s*>\s*$/.test(openTag)
        const closeRange = openEnd === -1
          ? null
          : findMatchingCloseTagRange(rawHtml, tag, openEnd + 1)
        const closeIndex = closeRange?.start ?? -1

        let inner = ''
        if (openEnd !== -1) {
          if (closeIndex !== -1 && openEnd < closeIndex)
            inner = rawHtml.slice(openEnd + 1, closeIndex)
          else
            inner = rawHtml.slice(openEnd + 1)
        }

        // Streaming mid-state: if the closing tag is being typed but not yet
        // complete, don't leak the partial `</tag` into content.
        if (closeIndex === -1)
          inner = stripTrailingPartialClosingTag(inner, tag)

        // Parse attrs from the opening tag only
        const attrs: [string, string][] = []
        const attrRegex = /\s([\w:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+)))?/g
        let m
        while ((m = attrRegex.exec(openTag)) !== null) {
          const name = m[1]
          if (!name || name.toLowerCase() === tag)
            continue
          const value = m[2] || m[3] || m[4] || ''
          attrs.push([name, value])
        }

        const loading = !options?.final && !selfClosing && closeRange == null

        const customNode = {
          type: tag,
          tag,
          content: stripWrapperNewlines(inner),
          raw: String(fromSource?.raw ?? htmlBlockNode.raw ?? rawHtml),
          loading,
          attrs: attrs.length ? attrs : undefined,
        } as ParsedNode

        if (includeSourceMap) {
          if (fromSource)
            customNode.sourceMap = createSourceMapFromOffsets(source, fromSource.start, fromSource.end, options)
          else
            applyNodeSourceMap(customNode, token, options)
        }
        return [
          customNode,
          index + 1,
        ]
      }
      if (includeSourceMap)
        applyNodeSourceMap(htmlBlockNode, token, options)
      return [htmlBlockNode, index + 1]
    }

    case 'table_open': {
      const [tableNode, newIndex] = parseTable(tokens, index, options, parseInlineTokens)
      if (includeSourceMap)
        applyNodeSourceMap(tableNode, token, options)
      return [tableNode, newIndex]
    }

    case 'dl_open': {
      const [definitionListNode, newIndex] = parseDefinitionList(tokens, index, options, parseInlineTokens)
      if (includeSourceMap)
        applyNodeSourceMap(definitionListNode, token, options)
      return [definitionListNode, newIndex]
    }

    case 'footnote_open': {
      const [footnoteNode, newIndex] = parseFootnote(tokens, index, options, parseInlineTokens)
      if (includeSourceMap)
        applyNodeSourceMap(footnoteNode, token, options)
      return [footnoteNode, newIndex]
    }

    case 'hr': {
      const node = parseThematicBreak()
      if (includeSourceMap)
        applyNodeSourceMap(node, token, options)
      return [node, index + 1]
    }
    default:
      break
  }

  return null
}

type ContainerParser = (
  tokens: MarkdownToken[],
  index: number,
  options: ParseOptions | undefined,
  parseInlineTokens: ParseInlineTokensFn,
) => [AdmonitionNode, number]

type ContainerMatcher = (
  tokens: MarkdownToken[],
  index: number,
  options: ParseOptions | undefined,
  parseInlineTokens: ParseInlineTokensFn,
) => [AdmonitionNode, number] | null

export function parseCommonBlockToken(
  tokens: MarkdownToken[],
  index: number,
  options: ParseOptions | undefined,
  handlers: {
    parseContainer?: ContainerParser
    matchAdmonition?: ContainerMatcher
  } | undefined,
  parseInlineTokens: ParseInlineTokensFn,
): [ParsedNode, number] | null {
  const basicResult = parseBasicBlockToken(tokens, index, options, parseInlineTokens)
  if (basicResult)
    return basicResult

  const token = tokens[index]
  const includeSourceMap = options?.includeSourceMap === true
  switch (token.type) {
    case 'container_warning_open':
    case 'container_info_open':
    case 'container_note_open':
    case 'container_tip_open':
    case 'container_danger_open':
    case 'container_caution_open':
    case 'container_error_open': {
      if (handlers?.parseContainer) {
        const result = handlers.parseContainer(tokens, index, options, parseInlineTokens)
        if (includeSourceMap)
          applyPairedBlockSourceMap(result[0], token, tokens[result[1] - 1], options)
        return result
      }
      break
    }

    case 'container_open': {
      if (handlers?.matchAdmonition) {
        const result = handlers.matchAdmonition(tokens, index, options, parseInlineTokens)
        if (result) {
          if (includeSourceMap)
            applyPairedBlockSourceMap(result[0], token, tokens[result[1] - 1], options)
          return result
        }
      }
      break
    }

    case 'vmr_container_open': {
      const result = parseVmrContainer(tokens, index, options, parseInlineTokens)
      if (includeSourceMap)
        applyPairedBlockSourceMap(result[0], token, tokens[result[1] - 1], options)
      return result
    }
    default:
      break
  }

  return null
}
