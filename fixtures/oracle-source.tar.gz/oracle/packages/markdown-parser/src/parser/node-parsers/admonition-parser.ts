import type { AdmonitionNode, MarkdownToken, ParsedNode, ParseOptions } from '../../types'
import type { ParseInlineTokensFn } from '../inline-parsers/inline-parser-types'
import { createLinkifyDemotionContextTracker } from '../linkifyHeuristics'
import { applyNodeSourceMap } from '../node-source-map'
import { parseBasicBlockToken } from './block-token-parser'
import { parseBlockquote } from './blockquote-parser'
import { parseList } from './list-parser'

export function parseAdmonition(
  tokens: MarkdownToken[],
  index: number,
  match: RegExpExecArray,
  options: ParseOptions | undefined,
  parseInlineTokens: ParseInlineTokensFn,
): [AdmonitionNode, number] {
  const kind = String(match[1] ?? 'note')
  const title = String(match[2] ?? (kind.charAt(0).toUpperCase() + kind.slice(1)))
  const admonitionChildren: ParsedNode[] = []
  const linkifyContext = createLinkifyDemotionContextTracker(options, true)
  let j = index + 1

  while (j < tokens.length && tokens[j].type !== 'container_close') {
    if (tokens[j].type === 'paragraph_open') {
      const contentToken = tokens[j + 1]
      if (contentToken) {
        const paragraphNode = {
          type: 'paragraph',
          children: parseInlineTokens(contentToken.children || [], String(contentToken.content ?? ''), undefined, linkifyContext.options()),
          raw: String(contentToken.content ?? ''),
        } as ParsedNode
        if (options?.includeSourceMap)
          applyNodeSourceMap(paragraphNode, tokens[j], options)
        admonitionChildren.push(paragraphNode)
        linkifyContext.remember(paragraphNode.raw)
      }
      j += 3 // Skip paragraph_open, inline, paragraph_close
    }
    else if (
      tokens[j].type === 'bullet_list_open'
      || tokens[j].type === 'ordered_list_open'
    ) {
      const [listNode, newIndex] = parseList(tokens, j, linkifyContext.options(), parseInlineTokens)
      if (options?.includeSourceMap)
        applyNodeSourceMap(listNode, tokens[j], options)
      admonitionChildren.push(listNode)
      linkifyContext.remember(listNode.raw)
      j = newIndex
    }
    else if (tokens[j].type === 'blockquote_open') {
      const [blockquoteNode, newIndex] = parseBlockquote(tokens, j, linkifyContext.options(), parseInlineTokens)
      if (options?.includeSourceMap)
        applyNodeSourceMap(blockquoteNode, tokens[j], options)
      admonitionChildren.push(blockquoteNode)
      linkifyContext.remember(blockquoteNode.raw)
      j = newIndex
    }
    else {
      const handled = parseBasicBlockToken(tokens, j, linkifyContext.options(), parseInlineTokens)
      if (handled) {
        admonitionChildren.push(handled[0])
        linkifyContext.remember(handled[0].raw)
        j = handled[1]
      }
      else {
        j++
      }
    }
  }

  const admonitionNode: AdmonitionNode = {
    type: 'admonition',
    kind,
    title,
    children: admonitionChildren,
    raw: `:::${kind} ${title}\n${admonitionChildren
      .map(child => child.raw)
      .join('\n')}\n:::`,
  }

  return [admonitionNode, j + 1] // Skip container_close
}
