import type { FactoryOptions } from './factory'
import type {
  CompatibleMarkdownItPlugin,
  MarkdownIt,
  MarkdownItPlugin,
} from './markdown-it-types'
import type { MarkdownToken } from './types'
import markdownItFootnote from 'markdown-it-footnote'
import markdownItIns from 'markdown-it-ins'
import markdownItMark from 'markdown-it-mark'
import markdownItSup from 'markdown-it-sup'

import * as markdownItCheckbox from 'markdown-it-task-checkbox'
import { factory } from './factory'
import {
  parseInlineTokens,
  parseMarkdownToStructure,
  processTokens,
} from './parser'
import { getCachedSourceLineOffsets, getParserRuntime } from './parser/runtime'
import { applyInlinePairs } from './plugins/inlinePairs'

// Module-level registry for callers that want to add plugins to every
// `getMarkdown()` instance without modifying call sites. Useful for tests
// or apps that want a central place to `use` plugins.
export type MarkdownPluginRegistration<TParams extends unknown[] = any[]>
  = | CompatibleMarkdownItPlugin<TParams>
    | readonly [CompatibleMarkdownItPlugin<TParams>, ...TParams]

const _registeredMarkdownPlugins: MarkdownPluginRegistration[] = []

export function registerMarkdownPlugin(plugin: MarkdownPluginRegistration) {
  _registeredMarkdownPlugins.push(plugin)
}

export function clearRegisteredMarkdownPlugins() {
  _registeredMarkdownPlugins.length = 0
}

// Re-export config
export { setDefaultMathOptions } from './config'

// Re-export parser functions
export { parseInlineTokens, parseMarkdownToStructure, processTokens }
export type { MathOptions } from './config'

// Re-export utilities
export * from './customHtmlTags'
export { findMatchingClose } from './findMatchingClose'
export * from './htmlRenderUtils'
export * from './htmlTags'
export type { MarkdownIt } from './markdown-it-types'
export * from './mermaidSvgSanitizer'
export { parseFenceToken } from './parser/inline-parsers/fence-parser'

// Re-export plugins
export { applyContainers } from './plugins/containers'
export { ESCAPED_TEX_BRACE_COMMANDS, isMathLike, TEX_BRACE_COMMANDS } from './plugins/isMathLike'
export { applyMath, KATEX_COMMANDS, normalizeStandaloneBackslashT } from './plugins/math'
// Re-export the node types for backward compatibility
export * from './types'

export interface GetMarkdownOptions extends FactoryOptions {
  plugin?: MarkdownPluginRegistration[]
  apply?: Array<(md: MarkdownIt) => void>
  /**
   * Custom translation function or translation map for UI texts
   * @default { 'common.copy': 'Copy' }
   */
  i18n?: ((key: string) => string) | Record<string, string>
}

function escapeHtml(value: unknown) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

function sanitizeFenceLanguage(info: string) {
  const firstToken = String(info || 'text').trim().split(/\s+/)[0] || 'text'
  const normalized = firstToken.replace(/[^\w+.#:-]/g, '-').replace(/-+/g, '-')
  return normalized || 'text'
}

function makeSafeDomId(value: string) {
  return value.replace(/[^\w:.+-]/g, '-').replace(/-+/g, '-')
}

export function getMarkdown(msgId: string = `editor-${Date.now()}`, options: GetMarkdownOptions = {}) {
  // keep legacy behaviour but delegate to new factory and reapply project-specific rules
  const md = factory(options)
  const mdState = md as unknown as Record<string, unknown>
  mdState.__markstreamRegisteredPluginCount = _registeredMarkdownPlugins.length
  mdState.__markstreamHasCustomParserExtensions = Boolean(
    options.plugin?.length
    || options.apply?.length
    || _registeredMarkdownPlugins.length,
  )

  // Setup i18n translator function
  const defaultTranslations: Record<string, string> = {
    'common.copy': 'Copy',
  }

  let t: (key: string) => string
  if (typeof options.i18n === 'function') {
    t = options.i18n
  }
  else if (options.i18n && typeof options.i18n === 'object') {
    const i18nMap = options.i18n as Record<string, string>
    t = (key: string) => i18nMap[key] ?? defaultTranslations[key] ?? key
  }
  else {
    t = (key: string) => defaultTranslations[key] ?? key
  }

  // apply user supplied plugins (md.use)
  if (Array.isArray(options.plugin)) {
    for (const p of options.plugin) {
      // allow both [plugin, opts] tuple or plugin function
      const pluginItem = p as unknown
      if (Array.isArray(pluginItem)) {
        const [fn, ...params] = pluginItem
        if (typeof fn === 'function')
          md.use(fn as MarkdownItPlugin, ...params)
      }
      else if (typeof pluginItem === 'function') {
        md.use(pluginItem as MarkdownItPlugin)
      }
      // otherwise ignore non-callable plugins
    }
  }

  // apply user supplied apply functions to mutate the md instance (e.g. md.block.ruler.before(...))
  if (Array.isArray(options.apply)) {
    for (const fn of options.apply) {
      try {
        fn(md)
      }
      catch (e) {
        // swallow errors to preserve legacy behaviour; developers can see stack in console

        console.error('[getMarkdown] apply function threw an error', e)
      }
    }
  }

  // Apply globally registered plugins (via registerMarkdownPlugin)
  if (_registeredMarkdownPlugins.length) {
    for (const p of _registeredMarkdownPlugins) {
      if (Array.isArray(p)) {
        const [fn, ...params] = p
        if (typeof fn === 'function')
          md.use(fn, ...params)
      }
      else if (typeof p === 'function') {
        md.use(p as MarkdownItPlugin)
      }
      // ignore non-callable registrations
    }
  }

  // Re-apply a few project specific plugins that were previously always enabled
  // `~sub~` uses a guarded built-in rule (numeric-range aware, see
  // plugins/inlinePairs.ts); `^sup^`/`==mark==`/`++ins++` keep the upstream
  // markdown-it plugins unchanged.
  md.use(applyInlinePairs)
  md.use(markdownItSup)
  md.use(markdownItMark)
  // Safely resolve default export or the module itself for checkbox plugin
  type CheckboxPluginFn = (md: MarkdownIt, opts?: unknown) => void
  const checkboxModule = markdownItCheckbox as unknown as { default?: CheckboxPluginFn } & CheckboxPluginFn
  const markdownItCheckboxPlugin = checkboxModule.default ?? checkboxModule
  md.use(markdownItCheckboxPlugin)
  md.use(markdownItIns)
  md.use(markdownItFootnote)

  md.block.ruler.before('footnote_def', 'pending_footnote_def', (state: {
    src: string
    bMarks: number[]
    tShift: number[]
    eMarks: number[]
    line: number
    env: { __markstreamFinal?: boolean, footnotes?: { refs?: Record<string, number> } }
  }, startLine: number, _endLine: number, silent: boolean) => {
    if (state.env.__markstreamFinal !== false || state.eMarks[startLine] !== state.src.length)
      return false
    const line = state.src.slice(state.bMarks[startLine] + state.tShift[startLine], state.eMarks[startLine])
    const pending = /^\[\^([^\]\s]*)(?:\](?::[\t ]*)?)?$/.exec(line)
    if (!pending)
      return false
    if (line.endsWith(']') && state.env.footnotes?.refs?.[`:${pending[1]}`] != null)
      return false
    // Keep an ambiguous trailing definition pending instead of flashing text or an empty footer.
    if (!silent)
      state.line = startLine + 1
    return true
  }, { alt: ['paragraph', 'reference'] })

  // Annotate fence tokens with unclosed meta using a lightweight line check
  md.core.ruler.after('block', 'mark_fence_closed', (state: unknown) => {
    const s = state as unknown as {
      src: string
      env?: Record<string, unknown>
      tokens: Array<{ type?: string, map?: number[], markup?: string, meta?: Record<string, unknown> }>
    }
    const src: string = s.src
    const envFinal = !!s.env?.__markstreamFinal
    // Tail parses retain absolute line maps and expose the full source here.
    let offsets: number[] | undefined
    for (const token of s.tokens) {
      if (token.type !== 'fence' || !token.map || !token.markup)
        continue
      const [openLine, endLine] = token.map
      let closed = envFinal
      if (!closed && endLine > openLine + 1) {
        offsets ??= getCachedSourceLineOffsets(getParserRuntime(md), src)
        const start = offsets[endLine - 1] ?? src.length
        const next = offsets[endLine]
        let end = next === undefined ? src.length : next - 1
        if (next !== undefined && src[end - 1] === '\r')
          end--
        const line = src.slice(start, end)
        let i = 0
        while (i < line.length && (line[i] === ' ' || line[i] === '\t')) i++
        let count = 0
        while (i + count < line.length && line[i + count] === token.markup[0]) count++
        let j = i + count
        while (j < line.length && (line[j] === ' ' || line[j] === '\t')) j++
        closed = count >= token.markup.length && j === line.length
      }
      const meta = token.meta ??= {}
      meta.unclosed = !closed
      meta.closed = closed
    }
  })

  // custom fence that uses msgId for unique ids
  md.renderer.rules.fence = (tokens: unknown, idx: number) => {
    const tokensAny = tokens as unknown as import('./types').MarkdownToken[]
    const token = tokensAny[idx]
    const tokenShape = token as unknown as { info?: string, content?: string }
    const info = String(tokenShape.info ?? '').trim()
    const str = String(tokenShape.content ?? '')
    const encodedCode = btoa(unescape(encodeURIComponent(str)))
    const language = sanitizeFenceLanguage(info)
    const escapedLanguage = escapeHtml(language)
    const uniqueId = makeSafeDomId(`editor-${msgId}-${idx}-${language}`)
    const copyLabel = escapeHtml(t('common.copy'))

    return `<div class="code-block" data-code="${encodedCode}" data-lang="${escapedLanguage}" id="${uniqueId}">
      <div class="code-header">
        <span class="code-lang">${escapeHtml(language.toUpperCase())}</span>
        <button class="copy-button" data-code="${encodedCode}">${copyLabel}</button>
      </div>
      <div class="code-editor"></div>
    </div>`
  }

  // reference rule (legacy)
  const RE_REFERENCE = /^\[(\d+)\]/
  const RE_REFERENCE_LABEL = /^\[([^\]\n]+)\]/
  const shouldPreserveReferenceStyleLink = (afterMatch: string) => {
    if (!afterMatch.startsWith('['))
      return false

    const nextLabelMatch = RE_REFERENCE_LABEL.exec(afterMatch)
    if (!nextLabelMatch)
      return afterMatch !== '[' && !/^\[\d+$/.test(afterMatch)

    const nextLabel = String(nextLabelMatch[1] ?? '')
    const remaining = afterMatch.slice(nextLabelMatch[0].length)

    // `[1][label](url)` is two adjacent constructs: a numeric reference
    // followed by a normal inline link.
    if (remaining.startsWith('('))
      return false

    // `[1][2]` and `[1][2][3]` are treated as chained numeric references
    // in this parser, while non-numeric labels should stay available for
    // CommonMark reference-style links.
    return !/^\d+$/.test(nextLabel)
  }
  const referenceInline = (state: unknown, silent?: boolean) => {
    const s = state as unknown as { src: string, pos: number, push: (type: string, tag?: string, nesting?: number) => MarkdownToken }
    if (s.src[s.pos] !== '[')
      return false
    const match = RE_REFERENCE.exec(s.src.slice(s.pos))
    if (!match)
      return false
    // Avoid false positives in JSON-like snippets, e.g. `"pages": [14]`
    const lookbehind = s.src.slice(Math.max(0, s.pos - 120), s.pos)
    if (/"[^"\n]{1,80}"\s*:\s*$/.test(lookbehind))
      return false

    // Check if this is part of a link: `[text](...)`, `[[text]](...)`, or `[text][id]`
    const afterMatch = s.src.slice(s.pos + match[0].length)
    // `](` handles nested-bracket link text, e.g. `[[8]](url)` where the inner `[8]`
    // must stay as text for the outer link parser to succeed.
    if (afterMatch.startsWith('](') || afterMatch.startsWith('(') || shouldPreserveReferenceStyleLink(afterMatch))
      return false
    if (!silent) {
      const id = match[1]
      const token = s.push('reference', 'span', 0)
      token.content = id
      token.markup = match[0]
      token.raw = match[0]
    }
    s.pos += match[0].length
    return true
  }

  md.inline.ruler.before('escape', 'reference', referenceInline)
  md.renderer.rules.reference = (tokens: unknown, idx: number) => {
    const tokensAny = tokens as unknown as import('./types').MarkdownToken[]
    const id = String(tokensAny[idx].content ?? '')
    return `<span class="reference-link" data-reference-id="${id}" role="button" tabindex="0" title="Click to view reference">${id}</span>`
  }

  const originalUse = md.use.bind(md)
  md.use = ((...args: Parameters<MarkdownIt['use']>) => {
    mdState.__markstreamHasCustomParserExtensions = true
    return originalUse(...args)
  }) as MarkdownIt['use']

  return md
}
